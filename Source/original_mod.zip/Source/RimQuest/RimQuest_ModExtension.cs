﻿using Verse;

namespace RimQuest
{
    public class RimQuest_ModExtension : DefModExtension
    {
        public bool canBeARimQuest = true;
    }
}
