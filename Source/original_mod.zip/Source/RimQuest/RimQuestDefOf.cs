﻿using RimWorld;
using Verse;

namespace RimQuest
{
    [DefOf]
    public static class RimQuestDefOf
    {
        public static JobDef RQ_QuestWithPawn;
    }
}