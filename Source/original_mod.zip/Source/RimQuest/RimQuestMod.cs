﻿using Verse;

namespace RimQuest
{
    public class RimQuestMod : Mod
    {
        public RimQuestMod(ModContentPack content) : base(content)
        {
           
        }
    }
}